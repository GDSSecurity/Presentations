//
//  LoginViewController.h
//  loginpage
//
//  Created by Ronald Gutierrez on 11/11/13.
//  Copyright (c) 2013 rontest. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController<UITextFieldDelegate, UITableViewDataSource>
{
    UITableView *mainLoginInfo;
    UITextField *usernameField;
    UITextField *passwordField;
}

@property(nonatomic, retain) UITextField *usernameField;
@property(nonatomic, retain) UITextField *passwordField;

@end
