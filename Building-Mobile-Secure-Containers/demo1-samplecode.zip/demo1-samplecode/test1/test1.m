//
//  test1.m
//  test1
//
//  Created by Ronald Gutierrez on 11/12/13.
//  Copyright (c) 2013 rontest. All rights reserved.
//

#import "test1.h"
#import "LoginViewController.h"
#import <objc/runtime.h>
#import <Foundation/Foundation.h>

@implementation test1

+(void)load
{
    NSLog(@"LOAD CALLED ON SWIZZLED AppDelegate");
    Method original, swizzled;

    unsigned int numberOfClasses = 0;
    // Get a list of objc classes
    Class *classes = objc_copyClassList(&numberOfClasses);
    
    // Go through all of the classes
    for (unsigned int i = 0; i < numberOfClasses; ++i)
    {
        Class class = classes[i];
        NSString *className = [NSString stringWithCString:class_getName(class) encoding:NSUTF8StringEncoding];
        
        // We only care of about classes which conform to the UIApplicationDelegate method
        if (class_conformsToProtocol(class, @protocol(UIApplicationDelegate)))
        {
            // Swizzle time
            original = class_getInstanceMethod(class, @selector(application:didFinishLaunchingWithOptions:));
            swizzled = class_getInstanceMethod(self, @selector(swizzled_application:didFinishLaunchingWithOptions:));
            method_exchangeImplementations(original, swizzled);
        }
    }
}

- (BOOL)swizzled_application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    NSLog(@"Inside of the Swizzled didFinishLaunchingWithOptions");
    LoginViewController* loginController = [[LoginViewController alloc] init];
    [application delegate].window.rootViewController = loginController;
    [loginController viewDidLoad];
    
    //BOOL returnValue = [self swizzled_application:application didFinishLaunchingWithOptions:launchOptions];
    
    return YES;
}

@end
