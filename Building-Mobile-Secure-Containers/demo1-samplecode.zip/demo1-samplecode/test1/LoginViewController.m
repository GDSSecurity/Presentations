//
//  LoginViewController.m
//  loginpage
//
//  Created by Ronald Gutierrez on 11/11/13.
//  Copyright (c) 2013 rontest. All rights reserved.
//

#import "LoginViewController.h"

@implementation LoginViewController

@synthesize usernameField,passwordField;

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    
    self.usernameField = nil;
    self.passwordField = nil;
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    mainLoginInfo.backgroundColor = [UIColor clearColor];
    usernameField.text = @"";
    passwordField.text = @"";
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidLoad];
    mainLoginInfo  = [[UITableView alloc] initWithFrame:CGRectMake(0,0, 320,600) style:UITableViewStyleGrouped];
    mainLoginInfo.dataSource = self;
    [self.view addSubview:mainLoginInfo];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    mainLoginInfo  = [[UITableView alloc] initWithFrame:CGRectMake(0,0, 320,600) style:UITableViewStyleGrouped];
    mainLoginInfo.dataSource = self;
    [self.view addSubview:mainLoginInfo];
    /*  [super viewDidLoad];
     
     mainLoginInfo  = [[UITableView alloc] initWithFrame:CGRectMake(0,90, 320,150) style:UITableViewStyleGrouped];
     mainLoginInfo.dataSource = self;
     [self.view addSubview:mainLoginInfo];
     
     */
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldClear:(UITextField *)textField{
    return YES;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return YES;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
    // Return the number of sections.
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 44.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    // Configure the cell...
    
    
    tableView.separatorStyle= UITableViewCellSeparatorStyleSingleLine;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    switch (indexPath.row) {
        case 0:
            cell.textLabel.text = @"User Name";
            usernameField = [[UITextField alloc] initWithFrame:CGRectMake(115,12, 180, 31)];
            usernameField.textAlignment = UITextAlignmentCenter;
            usernameField.textColor = [UIColor blueColor];
            usernameField.clearButtonMode  = UITextFieldViewModeAlways;
            usernameField.delegate = self;
            usernameField.font = [UIFont fontWithName:@"Helvetica" size:14.0];
            [cell.contentView addSubview:usernameField];
            break;
        case 1:
            cell.textLabel.text = @"Password";
            passwordField = [[UITextField alloc] initWithFrame:CGRectMake(115,12, 180, 31)];
            passwordField.textAlignment = UITextAlignmentCenter;
            passwordField.textColor = [UIColor blueColor];
            passwordField.clearButtonMode = UITextFieldViewModeAlways;
            passwordField.secureTextEntry = YES;
            passwordField.delegate = self;
            passwordField.font = [UIFont fontWithName:@"Helvetica" size:14.0];
            [cell.contentView addSubview:passwordField];
            break;
        default:
            break;
    }
    
    
    
    return cell;
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    if (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft ||
        toInterfaceOrientation == UIInterfaceOrientationLandscapeRight)
    {
        
        mainLoginInfo.frame = CGRectMake(30,60,420, 150);
        usernameField.frame = CGRectMake(145,12,250,31);
        passwordField.frame = CGRectMake(145, 12,250, 31);
        
    }
    
    else
    {
        
        
        mainLoginInfo.frame = CGRectMake(0,90, 320,150);
        usernameField.frame = CGRectMake(115,12, 180, 31);
        passwordField.frame = CGRectMake(115,12, 180, 31);
        
    }
}



@end
